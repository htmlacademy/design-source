const button = document.querySelector('.promo__button');
const modal = document.querySelector('.modal');
const mask = document.querySelector('.mask');

button.addEventListener('click', () => {
  modal.classList.add('modal__opened');
  mask.classList.add('mask__opened');
  modal.classList.remove('modal__closed');
  mask.classList.remove('mask__closed');
});

mask.addEventListener('click', () => {
  modal.classList.remove('modal__opened');
  mask.classList.remove('mask__opened');
  modal.classList.add('modal__closed');
  mask.classList.add('mask__closed');

  setTimeout(() => {
    modal.classList.remove('modal__closed');
    mask.classList.remove('mask__closed');
  }, 500);
});
